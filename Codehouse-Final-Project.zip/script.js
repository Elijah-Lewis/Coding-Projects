let colorlist = ['gold', 'yellow', 'turquoise', 'red'];
var friend;

function preload(){
  friend = loadImage("Friend20thCenturyBoys.jpg");
}

function setup() {
  createCanvas(600, 600, WEBGL);
  pictureObject = createPicture3D(friend, 10, 2.5, .2);
}

function draw() {
  orbitControl();
  background(255);
  pictureObject.show();

  noFill();
  strokeWeight(50);
  ellipse(0, 0, 500, 500);
}