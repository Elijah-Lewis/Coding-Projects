var wave;
var storm;
let myFont;
let screenState = "nothing";

function preload(){
  wave = loadImage("GreatWaveOffKanagawa.jpg");
  storm = loadImage("storm.jpg");
  myFont = loadFont("mexcellent rg.otf");
}


function setup() {
	createCanvas(windowWidth, windowHeight, WEBGL);
	background(230, 230, 230);
  textFont(myFont);


  
	
	picture1 = createPicture3D(
  	wave,      // The p5.Image object created from "loadImage()"
  	5,        // How thick the 3D rendered image is (i.e. how many cube pixels of size "size" it is on z-axis)  
  	2,         // The size of a unit "box()" making up part of the image  
    .2,   // A scaling factor (0.1 scales the image by 0.1 to reduce detail, 1 is the full scale, 0.4 is a good default)  
	);


picture2 = createPicture3D(
  	storm,      // The p5.Image object created from "loadImage()"
  	5,        // How thick the 3D rendered image is (i.e. how many cube pixels of size "size" it is on z-axis)  
  	.5,         // The size of a unit "box()" making up part of the image  
    .2,   // A scaling factor (0.1 scales the image by 0.1 to reduce detail, 1 is the full scale, 0.4 is a good default)  
	);


  
  //this was gonna be used to make 3d text
word = createWord3D(
  	"Your Journey is Neverending",       // The actual character that you want to draw (anything that can be passed into "text()")
  	2,        // How thick the 3D rendered letter is (i.e. how many cube pixels of size "size" it is on z-axis)  
  	2,         // The size of a unit "box()" making up part of the letter  
  	30,   // The size of the canvas it renders the letter on (higher is more detailed, 30-40 is a good range)  
  	true,     // [OPTIONAL, default = true] Gives the bevelled, embossed 3D look (as seen in screenshot)  
  	"Mexcellent",         // [OPTIONAL, default = "Georgia"] Gives the font uses, can be any default ones or anything added  
  	BOLD         // [OPTIONAL, default = BOLD] Gives the chosen style out of BOLD, NORMAL, ITALIC  
	);

}

function draw() {
  if (screenState == "nothing"){
    background(0);
  }
  else if(screenState == "image 1"){
    background(0);
    normalMaterial();
    picture1.show();
  }
  else if (screenState == "text 3D"){
    background(0);
    word.show();
  }
  else if(screenState == "image 2"){
    background("yellow");
    picture2.show();
  }
  else if(screenState == "text"){
    background(random(255), random(255), random(255));
    textSize(42.5);
    fill("black");
    text("Your Journey is Neverending", -275, 0);
  }
}

function keyPressed(){
  if (keyCode == RIGHT_ARROW){
    if(screenState == "nothing"){
      screenState = "image 1";
      print("the right arrow was pressed");
    }
    else if(screenState == "image 1"){
      screenState = "text 3D";
      print("the right arrow was pressed");
    }
    else if(screenState == "text 3D"){
      screenState = "image 2";
      print("the right arrow was pressed");
    }
    else if(screenState == "image 2"){
      screenState = "text";
      print("the right arrow was pressed");
    } 
    else if(screenState == "text"){
      screenState = "nothing";
      print("the right arrow was pressed");
    }
  }


  if (keyCode == LEFT_ARROW){
    if(screenState == "nothing"){
      screenState = "text";
      print("the left arrow was pressed");
    }
    else if(screenState == "image 1"){
      screenState = "nothing";
      print("the left arrow was pressed");
    }
    else if(screenState == "text 3D"){
      screenState = "image 1";
      print("the left arrow was pressed");
    }
    else if(screenState == "image 2"){
      screenState = "text 3D";
      print("the left arrow was pressed");
    }
    else if(screenState == "text"){
      screenState = "image 2";
      print("the left arrow was pressed");
    }
  }
}