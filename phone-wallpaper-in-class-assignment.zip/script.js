let colorlist = ['gold', 'yellow', 'turquoise', 'red']
var live = "off";

function setup() {
  createCanvas(390, 844);
  background("yellow");
  strokeWeight(1);
}

function draw() {
  for(let r = 0; r < windowWidth; r= r + 50){
    fill("red");
    ellipse(r, 422, 100, 100);
  }
}

